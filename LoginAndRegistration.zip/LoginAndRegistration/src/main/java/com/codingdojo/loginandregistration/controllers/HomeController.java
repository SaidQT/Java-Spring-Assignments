package com.codingdojo.loginandregistration.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.codingdojo.loginandregistration.models.LoginUser;
import com.codingdojo.loginandregistration.models.User;
import com.codingdojo.loginandregistration.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class HomeController {
	@Autowired
	private UserService userServ;

	@GetMapping("/")
	public String index(@ModelAttribute("user") User newUser, Model model) {
		model.addAttribute("newUser", new User());
		model.addAttribute("newLogin", new LoginUser());
		return "register.jsp";
	}
	@GetMapping("/home")
	public String home(HttpSession session) {
		if (session == null) {

			session.setAttribute(userName, session.getName())
		}
		session.setAttribute("username", getUserName());
	}
	
	
	@PostMapping("/register")
	public String register(@Valid @ModelAttribute("user") User newUser, 
	                       BindingResult result, Model model, HttpSession session) {

	    if (result.hasErrors()) {
	        model.addAttribute("newUser", new User()); 
	        return "register.jsp";
	    }
	    User user= userServ.register(newUser, result);
	    return "redirect:/"; 
	}


	@PostMapping("/login")
	public String login(@Valid @ModelAttribute("loginUser") LoginUser newLogin, 
	                    BindingResult result, Model model, HttpSession session) {
	    if (result.hasErrors()) {
	        model.addAttribute("newLogin", new LoginUser());
	        return "register.jsp"; 
	    }
	    
	    
	    User user = userServ.login(newLogin, result);
	    
	    if (user == null) {
	        return "index.jsp";
	    }
	    
	    session.setAttribute("userid", user.getId()); 
	    
	    return "redirect:/home";
	}


}


