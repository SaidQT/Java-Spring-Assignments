package com.assignments.LoginandRegistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginandRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginandRegistrationApplication.class, args);
	}

}
